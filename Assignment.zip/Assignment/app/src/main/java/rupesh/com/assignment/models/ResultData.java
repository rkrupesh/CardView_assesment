package rupesh.com.assignment.models;

import java.util.List;

public class ResultData {

    private String title;

    public String getTitle() { return this.title; }

    public void setTitle(String title) { this.title = title; }

    private List<Dictionary> rows;

    public List<Dictionary> getRows() { return this.rows; }

    public void setRows(List<Dictionary> rows) { this.rows = rows; }

    }
