package rupesh.com.assignment.models;

public class Dictionary {

    private String title;

    public String getTitle() { return this.title; }

    public void setTitle(String title) { this.title = title; }

    private String description;

    public String getDescription() { return this.description; }

    public void setDescription(String description) { this.description = description; }

    private String imageHref;

    public String getImageHref() { return this.imageHref; }

    public void setImageHref(String imageHref) { this.imageHref = imageHref; }
}
